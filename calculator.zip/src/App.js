import "./Calculator"
import './App.css';
import Calculator from "./Calculator";

function App() {
  return (
    <div>
    <Calculator/>
    </div>
  );
}

export default App;
